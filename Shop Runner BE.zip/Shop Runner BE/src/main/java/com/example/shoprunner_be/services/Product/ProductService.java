package com.example.shoprunner_be.services.Product;

import com.example.shoprunner_be.dtos.Product.ProductColorDTO;
import com.example.shoprunner_be.dtos.Product.ProductDTO;
import com.example.shoprunner_be.dtos.Product.ProductSizeDTO;
import com.example.shoprunner_be.entitys.Product.Product;
import com.example.shoprunner_be.entitys.Product.ProductColor;
import com.example.shoprunner_be.entitys.Product.ProductSize;

import java.util.List;

public interface ProductService {
    List<Product> getAllProducts();

    Product getProductById(Long ProductId);

    List<Product> getProductByCategoryId(Long categoryId);

    Product addProduct(ProductDTO productDTO);

    List<ProductColor> addProductColors(Long productId, ProductColorDTO productColorDTO);

    List<ProductSize> addProductSizes(Long productId, ProductSizeDTO productSizeDTO);

    Product updateProduct(Long ProductId, ProductDTO productDTO);

    void deleteProduct(Long productId);
}
